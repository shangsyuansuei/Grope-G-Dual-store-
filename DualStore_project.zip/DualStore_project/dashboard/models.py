from django.db import models
from django.utils import timezone
from django.db.models import Sum


class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=8, decimal_places=2)

    discount_price = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True
    )
    discount_start = models.DateTimeField(null=True, blank=True)
    discount_end = models.DateTimeField(null=True, blank=True)
    image = models.ImageField(upload_to="product_images/", blank=True, null=True)

    def __str__(self):
        return self.name

    def is_discount_active(self):
        now = timezone.now()
        return (
            self.discount_price is not None
            and self.discount_start is not None
            and self.discount_end is not None
            and self.discount_start <= now <= self.discount_end
        )

    def get_current_price(self):
        return self.discount_price if self.is_discount_active() else self.price

    @property
    def inventory(self):
        stock_in = (
            self.transaction_set.filter(transaction_type=1).aggregate(Sum("amount"))[
                "amount__sum"
            ]
            or 0
        )
        stock_out = (
            self.transaction_set.filter(transaction_type=-1).aggregate(Sum("amount"))[
                "amount__sum"
            ]
            or 0
        )
        return stock_in - stock_out


class Transaction(models.Model):
    TRANSACTION_TYPE_CHOICES = [
        (1, "IN"),  # 進貨
        (-1, "OUT"),  # 出貨
    ]

    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    transaction_type = models.IntegerField(choices=TRANSACTION_TYPE_CHOICES)
    amount = models.PositiveIntegerField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.get_transaction_type_display()} - {self.product.name} x {self.amount}"


class Customer(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()

    def __str__(self):
        return self.name


class Order(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)  # ✅ 新增這行

    def __str__(self):
        return f"Order #{self.id} - {self.customer.name}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    quantity = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"
