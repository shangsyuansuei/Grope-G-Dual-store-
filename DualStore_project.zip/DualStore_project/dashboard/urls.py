from django.urls import path
from . import views
from .views import (
    ProductListView,
    ProductDetailView,
    ProductCreateView,
    ProductUpdateView,
    ProductDeleteView,
    order_list,
)

urlpatterns = [
    path("", views.dashboard_home, name="dashboard_home"),  # ✅ 後台首頁
    # 商品管理
    path("products/", ProductListView.as_view(), name="product_list"),
    path("product/new/", ProductCreateView.as_view(), name="product_new"),
    path("product/<int:pk>/", ProductDetailView.as_view(), name="product_detail"),
    path("product/<int:pk>/edit/", ProductUpdateView.as_view(), name="product_edit"),
    path(
        "product/<int:pk>/delete/", ProductDeleteView.as_view(), name="product_delete"
    ),
    # 訂單管理
    path("orders/", order_list, name="order_list"),
    path("order/<int:order_id>/", views.order_detail, name="order_detail"),
    # 顧客管理
    path("customers/", views.customer_list, name="customer_list"),
    # 交易紀錄
    path("transactions/", views.transaction_list, name="transaction_list"),
    # 進出貨
    path("stock-in/", views.stock_in_view, name="stock_in"),
]
