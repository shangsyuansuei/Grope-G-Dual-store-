from django.shortcuts import redirect, render, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView

from .models import Product, Category, Order, OrderItem, Customer, Transaction
from dashboard.models import Order
from .forms import StockInForm
from django.contrib import messages
from django.utils import timezone


# 顧客列表
def customer_list(request):
    customers = Customer.objects.all()
    return render(request, "dashboard/customer_list.html", {"customers": customers})


# 商品列表
class ProductListView(ListView):
    model = Product
    template_name = "dashboard/product_list.html"
    context_object_name = "products"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        categories = Category.objects.all()
        categorized_products = []

        for category in categories:
            products_in_category = Product.objects.filter(category=category)
            categorized_products.append((category, products_in_category))

        context["categorized_products"] = categorized_products
        return context


# 商品詳情
class ProductDetailView(DetailView):
    model = Product
    template_name = "dashboard/product_detail.html"
    context_object_name = "product"


# 新增商品
class ProductCreateView(CreateView):
    model = Product
    template_name = "dashboard/product_new.html"
    fields = [
        "name",
        "price",
        "category",
        "discount_price",
        "discount_start",
        "discount_end",
        "image",
    ]
    success_url = reverse_lazy("product_list")


# 編輯商品
class ProductUpdateView(UpdateView):
    model = Product
    template_name = "dashboard/product_edit.html"
    fields = [
        "name",
        "price",
        "category",
        "discount_price",
        "discount_start",
        "discount_end",
        "image",
    ]
    success_url = reverse_lazy("product_list")


# 刪除商品
class ProductDeleteView(DeleteView):
    model = Product
    template_name = "dashboard/product_delete.html"
    success_url = reverse_lazy("product_list")


# 訂單列表


def order_list(request):
    orders = Order.objects.all().order_by("-created_at")  # 按照時間倒序排列

    order_data = []
    for order in orders:
        total = sum(item.price * item.quantity for item in order.orderitem_set.all())
        order_data.append(
            {
                "order": order,
                "total": total,
            }
        )

    return render(request, "dashboard/order_list.html", {"order_data": order_data})


def order_detail(request, order_id):
    order = get_object_or_404(Order, pk=order_id)
    order_items = []

    for item in order.orderitem_set.all():
        subtotal = item.price * item.quantity
        order_items.append(
            {
                "product": item.product,
                "price": item.price,
                "quantity": item.quantity,
                "subtotal": subtotal,
            }
        )

    total = sum(i["subtotal"] for i in order_items)

    return render(
        request,
        "dashboard/order_detail.html",
        {
            "order": order,
            "items": order_items,
            "total": total,
        },
    )


# 後台首頁
def dashboard_home(request):
    return render(request, "dashboard/dashboard_home.html")


# 進出貨紀錄
def transaction_list(request):
    transactions = Transaction.objects.select_related("product").order_by("-date")
    return render(
        request, "dashboard/transaction_list.html", {"transactions": transactions}
    )


from .forms import StockInForm
from django.contrib import messages
from django.utils import timezone


def stock_in_view(request):
    if request.method == "POST":
        form = StockInForm(request.POST)
        if form.is_valid():
            product = form.cleaned_data["product"]
            amount = form.cleaned_data["amount"]

            # 建立進貨交易
            Transaction.objects.create(
                product=product, transaction_type=1, amount=amount, date=timezone.now()
            )

            messages.success(
                request, f"Stock in successful for {product.name} (+{amount})"
            )
            return redirect("transaction_list")
    else:
        form = StockInForm()

    return render(request, "dashboard/stock_in.html", {"form": form})
