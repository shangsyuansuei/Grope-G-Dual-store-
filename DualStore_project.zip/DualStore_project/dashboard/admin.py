from django.contrib import admin
from django.utils.html import mark_safe
from .models import Product, Category, Customer, Order, OrderItem, Transaction


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "price", "category", "inventory_display", "thumbnail")

    def inventory_display(self, obj):
        return obj.inventory

    inventory_display.short_description = "Inventory"

    def thumbnail(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" width="50" />')
        return "—"


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "customer_name", "customer_email", "created_at")

    def customer_name(self, obj):
        return obj.customer.name

    def customer_email(self, obj):
        return obj.customer.email


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("name", "email")


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ("order", "product", "price", "quantity")


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ("product", "transaction_type", "amount", "date")
    list_filter = ("transaction_type", "date")
    search_fields = ("product__name",)
