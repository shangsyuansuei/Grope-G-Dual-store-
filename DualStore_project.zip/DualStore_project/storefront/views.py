from django.shortcuts import render, get_object_or_404, redirect
from dashboard.models import Product, Order, OrderItem, Customer, Category
from .forms import OrderForm
from django.http import HttpResponseRedirect
from django.contrib import messages
from dashboard.models import Transaction
from django.contrib import messages
from django.shortcuts import redirect, get_object_or_404


def order_product(request, product_id):
    product = get_object_or_404(Product, pk=product_id)

    if request.method == "POST":
        form = OrderForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data["name"]
            email = form.cleaned_data["email"]
            quantity = form.cleaned_data["quantity"]

            # 如果顧客已存在就取出，否則建立
            customer, created = Customer.objects.get_or_create(
                email=email, defaults={"name": name}
            )

            # 建立訂單
            order = Order.objects.create(customer=customer)

            # 建立訂單明細
            OrderItem.objects.create(
                order=order,
                product=product,
                price=product.price,
                quantity=quantity,
            )

            return redirect("order_success", order_id=order.id)  # ✅ 導到成功頁

    else:
        form = OrderForm()

    return render(
        request,
        "storefront/order_product.html",
        {
            "form": form,
            "product": product,
        },
    )


def home(request):
    categories = Category.objects.all()
    categorized_products = []

    for category in categories:
        products_in_category = Product.objects.filter(category=category)
        categorized_products.append((category, products_in_category))

    return render(
        request, "storefront/home.html", {"categorized_products": categorized_products}
    )


def order_success(request, order_id):
    order = get_object_or_404(Order, pk=order_id)
    return render(request, "storefront/order_success.html", {"order": order})


def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)

    # 初始化購物車
    cart = request.session.get("cart", {})

    # 如果已經有這個商品，就數量 +1
    if str(product_id) in cart:
        cart[str(product_id)] += 1
    else:
        cart[str(product_id)] = 1

    # 寫回 session
    request.session["cart"] = cart
    request.session.modified = True

    return redirect("storefront_home")


def cart_view(request):
    cart = request.session.get("cart", {})
    products = Product.objects.filter(id__in=cart.keys())

    cart_items = []
    total_price = 0

    for product in products:
        quantity = cart[str(product.id)]
        price = product.get_current_price()  # ✅ 改用折扣價邏輯
        subtotal = price * quantity
        cart_items.append(
            {
                "product": product,
                "quantity": quantity,
                "subtotal": subtotal,
                "unit_price": price,  # ✅ 可以一併傳過去模板給 JS 用
            }
        )
        total_price += subtotal

    return render(
        request,
        "storefront/cart.html",
        {"cart_items": cart_items, "total_price": total_price},
    )


def remove_from_cart(request, product_id):
    cart = request.session.get("cart", {})

    if str(product_id) in cart:
        del cart[str(product_id)]
        request.session["cart"] = cart
        request.session.modified = True
        messages.success(request, "Item removed from your cart")

    return redirect("cart_view")


def update_cart(request, product_id):
    if request.method == "POST":
        new_quantity = int(request.POST.get("quantity", 1))
        cart = request.session.get("cart", {})

        if new_quantity > 0:
            cart[str(product_id)] = new_quantity
        else:
            cart.pop(str(product_id), None)

        request.session["cart"] = cart
        request.session.modified = True
        messages.success(request, "Cart updated successfully")

    return redirect("cart_view")


def checkout_view(request):
    cart = request.session.get("cart", {})
    if not cart:
        messages.error(request, "Your cart is empty.")
        return redirect("cart_view")

    if request.method == "POST":
        form = OrderForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data["name"]
            email = form.cleaned_data["email"]

            customer, _ = Customer.objects.get_or_create(
                email=email, defaults={"name": name}
            )

            order = Order.objects.create(customer=customer)

            for product_id, quantity in cart.items():
                product = Product.objects.get(id=product_id)

                if quantity > product.inventory:
                    messages.error(
                        request,
                        f"{product.name} only has {product.inventory} items in stock.",
                    )
                    return redirect("cart_view")

                price = product.get_current_price()
                OrderItem.objects.create(
                    order=order, product=product, price=price, quantity=quantity
                )

                # ✅ 建立出貨紀錄
                Transaction.objects.create(
                    product=product, transaction_type=-1, amount=quantity
                )

            # ✅ 清空購物車
            request.session["cart"] = {}
            messages.success(request, "Your order has been placed successfully.")
            return redirect("order_success", order_id=order.id)
    else:
        form = OrderForm()

    return render(request, "storefront/checkout.html", {"form": form})


def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart = request.session.get("cart", {})

    current_quantity = cart.get(str(product_id), 0)
    if current_quantity + 1 > product.inventory:
        messages.error(request, f"Not enough stock for {product.name}.")
        return redirect("storefront_home")

    cart[str(product_id)] = current_quantity + 1
    request.session["cart"] = cart
    messages.success(request, f"{product.name} added to cart.")
    return redirect("storefront_home")


def update_cart(request, product_id):
    if request.method == "POST":
        quantity = int(request.POST.get("quantity", 1))
        product = get_object_or_404(Product, pk=product_id)

        if quantity > product.inventory:
            messages.error(
                request, f"Only {product.inventory} items available for {product.name}."
            )
        else:
            cart = request.session.get("cart", {})
            cart[str(product_id)] = quantity
            request.session["cart"] = cart
            messages.success(request, f"{product.name} quantity updated.")

    return redirect("cart_view")
