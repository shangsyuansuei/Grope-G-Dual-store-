from django import forms


class OrderForm(forms.Form):
    name = forms.CharField(label="姓名", max_length=100)
    email = forms.EmailField(label="Email")
